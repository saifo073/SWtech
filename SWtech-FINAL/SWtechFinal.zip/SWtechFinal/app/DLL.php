<?php
function banco($server, $user, $password, $db, $consulta) {
    $conexao = new mysqli($server, $user, $password, $db);
    
    if ($conexao->connect_error) {
        echo "Falha de conexão: (" . $conexao->connect_errno . ") - " . $conexao->connect_error;
        exit();
    }
    
    if (!$resultado = $conexao->query($consulta)) {
        echo "Falha na consulta: (" . $conexao->errno . ") - " . $conexao->error;
        exit();
    }
    
    $conexao->close();
    return $resultado;
}

function teste_login($sessao) {
    if ($sessao != "ok") {
        header("Location: login.php");
        exit;
    }
}
?>