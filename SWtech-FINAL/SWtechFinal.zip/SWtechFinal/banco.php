<?php
session_start();
require_once 'app/cons.php';
require_once 'app/DLL.php';
require_once 'app/enviar_verificacao.php';

$id_sessao = session_id();

/* B1 - PRIMEIRA ETAPA DO CADASTRO */
if(isset($_POST['B1'])){
    $nome = trim($_POST['nome'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $cpf = str_replace(['.', '-', ' '], '', $_POST['cpf'] ?? '');
    $endereco = trim($_POST['endereco'] ?? '');
    $bairro = trim($_POST['bairro'] ?? '');
    $cidade = trim($_POST['cidade'] ?? '');
    $estado = strtoupper(trim($_POST['estado'] ?? ''));
    $cep = trim($_POST['cep'] ?? '');

    if($nome === '' || strpos($email, '@') === false || strlen($cpf) !== 11 || $endereco === '' || $bairro === '' || $cidade === '' || strlen($estado) !== 2 || $cep === ''){
        $_SESSION['erro_cadastro'] = 'Confira os dados informados.';
        header('Location: cadastro1.php'); exit();
    }

    $check = "SELECT id FROM usuarios WHERE cpf = '$cpf' OR email = '$email'";
    $res_check = banco($server, $user, $password, $db, $check);
    if($res_check->fetch_assoc()){
        $_SESSION['erro_cadastro'] = 'Este CPF ou e-mail já está cadastrado.';
        header('Location: cadastro1.php'); exit();
    }

    $insert = "INSERT INTO usuarios (nome, email, cpf, endereco, bairro, cidade, estado, cep) 
               VALUES ('$nome', '$email', '$cpf', '$endereco', '$bairro', '$cidade', '$estado', '$cep')";
    banco($server, $user, $password, $db, $insert);

    $res_id = banco($server, $user, $password, $db, "SELECT id FROM usuarios WHERE email = '$email'");
    $linha_id = $res_id->fetch_assoc();
    $_SESSION['temp_id_usuario'] = $linha_id['id'];

    header('Location: cadastro2.php'); exit();
}

/* B2 - SEGUNDA ETAPA DO CADASTRO E ENVIO DO E-MAIL */
if(isset($_POST['B2'])){
    if(!isset($_SESSION['temp_id_usuario'])){ header('Location: cadastro1.php'); exit(); }
    $login = trim($_POST['login'] ?? '');
    $senha = $_POST['senha'] ?? '';
    if($login === '' || strlen($senha) < 6){
        $_SESSION['erro_cadastro2'] = 'Informe um login e uma senha com pelo menos 6 caracteres.';
        header('Location: cadastro2.php'); exit();
    }

    $id_usuario = (int)$_SESSION['temp_id_usuario'];
    $senha_md5 = md5($senha);

    $check_login = "SELECT id FROM logins WHERE login = '$login'";
    $res_login = banco($server, $user, $password, $db, $check_login);
    if($res_login->fetch_assoc()){
        $_SESSION['erro_cadastro2'] = 'Este login já está em uso.';
        header('Location: cadastro2.php'); exit();
    }

    $insert_login = "INSERT INTO logins (login, senha, id_usuario) VALUES ('$login', '$senha_md5', $id_usuario)";
    banco($server, $user, $password, $db, $insert_login);

    $token = rand(100000, 999999);
    $token_hash = md5($token);
    $update_token = "UPDATE usuarios SET token_verificacao = '$token_hash' WHERE id = $id_usuario";
    banco($server, $user, $password, $db, $update_token);

    $res_user = banco($server, $user, $password, $db, "SELECT nome, email FROM usuarios WHERE id = $id_usuario");
    $usuario = $res_user->fetch_assoc();

    $enviado = enviarVerificacao($usuario['email'], $usuario['nome'], $token);
    unset($_SESSION['temp_id_usuario']);
    $_SESSION['aviso_cadastro'] = $enviado ? 'Cadastro concluído! Enviamos um link para confirmar seu e-mail.' : 'Cadastro concluído, mas não foi possível enviar o e-mail. Confira a configuração SMTP.';
    header('Location: login.php'); exit();
}

/* B3 - ENTRAR */
if(isset($_POST['B3'])){
    $login = trim($_POST['login'] ?? '');
    $senha = md5($_POST['senha'] ?? '');

    $consulta = "SELECT l.id, l.id_usuario, u.nome FROM logins l 
                 INNER JOIN usuarios u ON u.id = l.id_usuario 
                 WHERE l.login = '$login' AND l.senha = '$senha'";
    $resultado = banco($server, $user, $password, $db, $consulta);

    if($linha = $resultado->fetch_assoc()){
        $_SESSION['Logado'] = 'ok';
        $_SESSION['Nome_Usuario'] = $linha['nome'];
        $_SESSION['id_usuario'] = (int)$linha['id_usuario'];
        header('Location: confirmar.php'); exit();
    }
    $_SESSION['erro_login'] = true;
    header('Location: login.php'); exit();
}

/* B4 - REGISTRAR PEDIDO SIMULADO */
if(isset($_POST['B4'])){
    if(!isset($_SESSION['Logado']) || $_SESSION['Logado'] !== 'ok'){ header('Location: login.php'); exit(); }
    $id_usuario = (int)$_SESSION['id_usuario'];
    $forma = $_POST['forma_pagamento'] ?? '';
    $parcelas = $_POST['parcelas'] ?? '';
    $formas_validas = ['Pix', 'Boleto', 'Cartao de Credito'];

    if(!in_array($forma, $formas_validas)){
        $_SESSION['erro_pedido'] = 'Selecione uma forma de pagamento válida.';
        header('Location: confirmar.php'); exit();
    }
    if($forma !== 'Cartao de Credito'){ $parcelas = ''; }

    $consulta_itens = "SELECT c.id_produto, c.quantidade, p.nome, p.preco 
                       FROM carrinho c INNER JOIN produtos p ON p.id = c.id_produto 
                       WHERE c.id_sessao = '$id_sessao'";
    $resultado_itens = banco($server, $user, $password, $db, $consulta_itens);

    $itens = [];
    $total = 0;
    $descricao = '';
    while($item = $resultado_itens->fetch_assoc()){
        $itens[] = $item;
        $total += $item['preco'] * $item['quantidade'];
        $descricao .= $item['nome'] . ' (Qtd: ' . $item['quantidade'] . ') | ';
    }

    if(count($itens) === 0){
        $_SESSION['erro_pedido'] = 'Não é possível finalizar um carrinho vazio.';
        header('Location: carrinho.php'); exit();
    }

    $numero = rand(100000, 999999);
    $data = date('Y-m-d H:i:s');
    $nome_usuario = $_SESSION['Nome_Usuario'];

    $insert_venda = "INSERT INTO vendas (numero_venda, usuario, descricao_itens, data_hora, total_venda, forma_pagamento, parcelas, id_usuario) 
                     VALUES ($numero, '$nome_usuario', '$descricao', '$data', $total, '$forma', '$parcelas', $id_usuario)";
    banco($server, $user, $password, $db, $insert_venda);

    $res_venda = banco($server, $user, $password, $db, "SELECT id FROM vendas WHERE numero_venda = $numero");
    $linha_venda = $res_venda->fetch_assoc();
    $id_venda = $linha_venda['id'];

    foreach($itens as $item){
        $produto_id = (int)$item['id_produto'];
        $quantidade = (int)$item['quantidade'];
        $preco = $item['preco'];
        $insert_item = "INSERT INTO itens_venda (id_venda, id_produto, quantidade, preco_unitario) 
                        VALUES ($id_venda, $produto_id, $quantidade, $preco)";
        banco($server, $user, $password, $db, $insert_item);
    }

    $delete_carrinho = "DELETE FROM carrinho WHERE id_sessao = '$id_sessao'";
    banco($server, $user, $password, $db, $delete_carrinho);

    $_SESSION['pedido'] = $numero;
    $_SESSION['pagamento_simulado'] = true;
    header('Location: sucesso.php'); exit();
}

/* B5 - ATUALIZAR QUANTIDADE DO CARRINHO */
if(isset($_POST['B5'])){
    $id_produto = (int)($_POST['id_produto'] ?? 0);
    $quantidade = (int)($_POST['quantidade'] ?? 1);
    if($id_produto > 0 && $quantidade > 0 && $quantidade <= 99){
        $update = "UPDATE carrinho SET quantidade = $quantidade 
                   WHERE id_sessao = '$id_sessao' AND id_produto = $id_produto";
        banco($server, $user, $password, $db, $update);
    }
    header('Location: carrinho.php'); exit();
}

/* B6 - ADICIONAR PRODUTO AO CARRINHO */
if(isset($_POST['B6'])){
    $id_produto = (int)($_POST['id_produto'] ?? 0);
    if($id_produto > 0){
        $res_prod = banco($server, $user, $password, $db, "SELECT id FROM produtos WHERE id = $id_produto");
        if($res_prod->fetch_assoc()){
            $res_carrinho = banco($server, $user, $password, $db, "SELECT quantidade FROM carrinho WHERE id_sessao = '$id_sessao' AND id_produto = $id_produto");
            if($atual = $res_carrinho->fetch_assoc()){
                $nova = min(99, (int)$atual['quantidade'] + 1);
                banco($server, $user, $password, $db, "UPDATE carrinho SET quantidade = $nova WHERE id_sessao = '$id_sessao' AND id_produto = $id_produto");
            }else{
                banco($server, $user, $password, $db, "INSERT INTO carrinho (id_sessao, id_produto, quantidade) VALUES ('$id_sessao', $id_produto, 1)");
            }
        }
    }
    header('Location: carrinho.php'); exit();
}

/* B7 - REMOVER PRODUTO */
if(isset($_POST['B7'])){
    $id_produto = (int)($_POST['id_produto'] ?? 0);
    $delete = "DELETE FROM carrinho WHERE id_sessao = '$id_sessao' AND id_produto = $id_produto";
    banco($server, $user, $password, $db, $delete);
    header('Location: carrinho.php'); exit();
}

header('Location: index.php');
exit();
?>