<?php
return [
    'host' => 'smtp.gmail.com',
    'username' => getenv('SWTECH_EMAIL') ?: '', // seu e-mail do Gmail
    'password' => getenv('SWTECH_EMAIL_PASSWORD') ?: '', // senha de aplicativo do Gmail
    'port' => 587,
    'encryption' => 'tls',
    'from_email' => getenv('SWTECH_EMAIL') ?: '', // seu e-mail do Gmail
    'from_name' => 'SWtech',
    'base_url' => getenv('SWTECH_BASE_URL') ?: 'http://localhost/SWtech'
];
