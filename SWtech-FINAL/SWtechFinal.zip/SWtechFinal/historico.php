<?php
session_start();
if(!isset($_SESSION['Logado']) || $_SESSION['Logado'] !== 'ok'){ header('Location: login.php'); exit(); }
require_once 'app/cons.php';
require_once 'app/DLL.php';

$id_usuario = (int)$_SESSION['id_usuario'];
$consulta = "SELECT id, numero_venda, data_hora, total_venda, forma_pagamento 
             FROM vendas WHERE id_usuario = $id_usuario ORDER BY data_hora DESC";
$pedidos = banco($server, $user, $password, $db, $consulta);
?>
<!DOCTYPE html>
<html lang="pt-br">
<head><meta charset="UTF-8"><title>Meus pedidos - SWtech</title><link rel="stylesheet" href="css/style.css"></head>
<body>
<nav class="navbar">
    <div class="logo">SWtech</div>
    <ul>
        <li><form method="POST" action="index.php"><button class="btn btn-primary">Início</button></form></li>
        <li><form method="POST" action="logout.php"><button class="btn btn-danger">Sair</button></form></li>
    </ul>
</nav>
<main class="container">
    <h1 class="section-title">Histórico de pedidos</h1>
    <?php if($pedidos->num_rows === 0){ ?>
        <p>Você ainda não realizou pedidos.</p>
    <?php }else{ ?>
        <table class="carrinho-tabela">
            <tr><th>Pedido</th><th>Data</th><th>Total</th><th>Pagamento</th></tr>
            <?php while($p = $pedidos->fetch_assoc()){ ?>
            <tr>
                <td>#<?php echo (int)$p['numero_venda']; ?></td>
                <td><?php echo htmlspecialchars($p['data_hora']); ?></td>
                <td>R$ <?php echo number_format($p['total_venda'], 2, ',', '.'); ?></td>
                <td><?php echo htmlspecialchars($p['forma_pagamento']); ?></td>
            </tr>
            <?php } ?>
        </table>
    <?php } ?>
</main>
</body>
</html>