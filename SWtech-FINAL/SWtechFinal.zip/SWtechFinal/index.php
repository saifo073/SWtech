<?php
session_start();
require_once 'app/cons.php';
require_once 'app/DLL.php';

$cat = $_POST['cat'] ?? 'todos';
if($cat === 'todos'){
    $consulta = "SELECT * FROM produtos ORDER BY id DESC";
}else{
    $consulta = "SELECT * FROM produtos WHERE categoria = '$cat' ORDER BY id DESC";
}
$resultado = banco($server, $user, $password, $db, $consulta);

$id_sessao = session_id();
$consulta_carrinho = "SELECT SUM(quantidade) AS total FROM carrinho WHERE id_sessao = '$id_sessao'";
$res_carrinho = banco($server, $user, $password, $db, $consulta_carrinho);
$qtd = $res_carrinho->fetch_assoc();
$quantidade_carrinho = $qtd['total'] ?? 0;
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SWtech - Tecnologia</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<nav class="navbar">
    <div class="logo">SWtech</div>
    <ul>
        <li><form method="POST" action="index.php"><input type="hidden" name="cat" value="todos"><button>Início</button></form></li>
        <li><form method="POST" action="index.php"><input type="hidden" name="cat" value="notebooks"><button>Notebooks</button></form></li>
        <li><form method="POST" action="index.php"><input type="hidden" name="cat" value="celulares"><button>Celulares</button></form></li>
        <li><form method="POST" action="index.php"><input type="hidden" name="cat" value="acessorios"><button>Acessórios</button></form></li>
        <li><form method="POST" action="login.php"><button>Login</button></form></li>
        <li><form method="POST" action="carrinho.php"><button>🛒 Carrinho (<?php echo (int)$quantidade_carrinho; ?>)</button></form></li>
        <?php if(isset($_SESSION['Logado']) && $_SESSION['Logado'] === 'ok'){ ?>
            <li><form method="POST" action="historico.php"><button>Meus pedidos</button></form></li>
            <li><form method="POST" action="cadastro_produto.php"><button>Cadastrar produto</button></form></li>
            <li><form method="POST" action="logout.php"><button>Sair</button></form></li>
        <?php } ?>
    </ul>
</nav>

<div class="banner">
    <img src="img/Banner.png" alt="Banner SWtech">
</div>

<main class="container">
    <h1 class="section-title">Produtos em destaque</h1>
    <div class="grid-produtos">
        <?php while($produto = $resultado->fetch_assoc()){ ?>
        <form method="POST" action="detalhes.php" style="margin:0">
            <input type="hidden" name="id" value="<?php echo (int)$produto['id']; ?>">
            <button type="submit" class="product-card">
                <img src="<?php echo htmlspecialchars($produto['imagem']); ?>" alt="<?php echo htmlspecialchars($produto['nome']); ?>">
                <h3><?php echo htmlspecialchars($produto['nome']); ?></h3>
                <p class="desc"><?php echo htmlspecialchars($produto['descricao']); ?></p>
                <div class="price">R$ <?php echo number_format($produto['preco'], 2, ',', '.'); ?></div>
                <span class="btn btn-primary" style="width:100%;">Ver detalhes</span>
            </button>
        </form>
        <?php } ?>
    </div>
</main>
</body>
</html>