<?php
session_start();
require_once 'app/cons.php';
require_once 'app/DLL.php';

$token = $_GET['token'] ?? '';

if($token === ''){
    header('Location: index.php'); exit();
}

$token_hash = md5($token);

$consulta = "SELECT id FROM usuarios WHERE token_verificacao = '$token_hash'";
$resultado = banco($server, $user, $password, $db, $consulta);

if($linha = $resultado->fetch_assoc()){
    $id = (int)$linha['id'];
    $update = "UPDATE usuarios SET email_verificado = 1, token_verificacao = NULL WHERE id = $id";
    banco($server, $user, $password, $db, $update);
    $msg = 'E-mail confirmado com sucesso!';
    $cor = '#38a169';
}else{
    $msg = 'Link inválido ou expirado.';
    $cor = '#c53030';
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head><meta charset="UTF-8"><title>Verificar e-mail - SWtech</title><link rel="stylesheet" href="css/style.css"></head>
<body>
<div class="wrapper-center">
    <div class="card-form" style="text-align:center">
        <h2 style="color:<?php echo $cor; ?>"><?php echo $msg; ?></h2>
        <p style="margin:20px 0"><a href="login.php" class="btn btn-primary">Ir para o Login</a></p>
    </div>
</div>
</body>
</html>