<?php
session_start();

if(!isset($_SESSION['Logado']) || $_SESSION['Logado'] != 'ok'){
    header('Location: index.html');
    exit;
}
?>

<html>
<head>
    <title>Equação</title>
</head>
<body>

<h1>Olá <?=$_SESSION['Nome']?></h1>

<form method="POST">
    A: <input type="text" name="a"><br/>
    B: <input type="text" name="b"><br/>
    C: <input type="text" name="c"><br/>
    
    <input type="submit" value="Calcular" name="b1">
    <input type="submit" value="Ver resultados" name="b2">
</form>

<?php
$texto = "";

if(isset($_POST['b1'])) {

    $a = $_POST['a'];
    $b = $_POST['b'];
    $c = $_POST['c'];

    if($a == 0){
        if($b == 0){
            $texto = "Equação inválida<br/>";
        } else {
            $x = -$c / $b;
            $texto = "x = $x<br/>";
        }
    } else {

        $d = ($b*$b)-(4*$a*$c); 

        if($d < 0) $texto = "Não possui raízes reais<br/>";
        elseif($d == 0) $texto = "x = ".(-$b/(2*$a))."<br/>";
        else {
            $x1 = (-$b + sqrt($d))/(2*$a);
            $x2 = (-$b - sqrt($d))/(2*$a);
            $texto = "x1 = $x1 | x2 = $x2<br/>";
        }
    }

    file_put_contents("resultados.txt", $texto, FILE_APPEND);
}

if(isset($_POST['b2'])){
    if(file_exists("resultados.txt")){
        $texto = file_get_contents("resultados.txt");
    }
}

echo $texto;
?>

<br><br>
<a href="logout.php">Sair</a>

</body>
</html>