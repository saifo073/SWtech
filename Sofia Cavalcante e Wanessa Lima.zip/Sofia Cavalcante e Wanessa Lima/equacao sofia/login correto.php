<?php
session_start();
extract($_POST);

if(isset($b1)) {
    $nome = $login.".dat";
    $pass = md5($senha);

    if (file_exists($nome)) {
        echo "Usuário já existe.<br/>";
    } else {
        file_put_contents($nome, $pass);
        echo "Usuário criado!<br/>";
    }

    echo "<a href='index.html'>Voltar</a>";
}

if(isset($b2)){
    $nome = $login.".dat";

    if(file_exists($nome)){
        $pass = file_get_contents($nome);

        if (md5($senha) == $pass){
            $_SESSION['Logado'] = 'ok';
            $_SESSION['Nome'] = $login;

            header('Location: formulario.php');
            exit;
        } else {
            echo "Senha incorreta!<br/>";
        }
    } else {
        echo "Usuário não existe!<br/>";
    }

    echo "<a href='index.html'>Voltar</a>";
}

if(isset($b3)){
    $nome = $login.".dat";

    if (file_exists($nome)) {
        unlink($nome);
        echo "Usuário excluído!<br/>";
    } else {
        echo "Usuário não existe.<br/>";
    }

    echo "<a href='index.html'>Voltar</a>";
}
?>