<?php
if(!isset($_SESSION)) session_start();

if(!isset($_SESSION['Logado']) || $_SESSION['Logado'] != 'ok'){
    header('location: index.html');
    exit;

} else {
    echo "<h1> Olá ".$_SESSION['Nome']."</h1>";
    echo "<img src='certo.png'><br/><br/>";
    
    session_destroy();
    echo "<a href='index.html'>Voltar para o Login</a>";
}
?>